create definer = root@`%` view goods_sku_expand as
select `a`.`id`             AS `sku_id`,
       `a`.`spu_id`         AS `spu_id`,
       `b`.`title`          AS `spu_title`,
       `b`.`img_url`        AS `spu_img`,
       `a`.`title`          AS `sku_title`,
       `a`.`img_url`        AS `sku_img`,
       `b`.`brand_id`       AS `brand_id`,
       `b`.`cate_id`        AS `cate_id`,
       `c`.`brand_name`     AS `brand_name`,
       `c`.`brand_logo`     AS `brand_logo`,
       `a`.`price`          AS `price`,
       `a`.`original_price` AS `original_price`,
       `a`.`stock`          AS `stock`,
       `a`.`sales`          AS `sales`,
       `a`.`matching`       AS `matching`
from ((`needle_db`.`goods_sku` `a` left join `needle_db`.`goods_spu` `b` on ((`a`.`spu_id` = `b`.`id`)))
         left join `needle_db`.`goods_brand` `c` on ((`b`.`brand_id` = `c`.`id`)))
where (`a`.`status` = '1');

