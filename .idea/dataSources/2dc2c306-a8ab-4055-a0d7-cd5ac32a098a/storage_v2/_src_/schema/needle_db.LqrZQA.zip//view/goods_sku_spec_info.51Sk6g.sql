create definer = root@`%` view goods_sku_spec_info as
select `a`.`sku_id`        AS `sku_id`,
       `b`.`spec_id`       AS `spec_id`,
       `c`.`spec_name`     AS `spec_name`,
       `a`.`spec_value_id` AS `spec_value_id`,
       `b`.`spec_value`    AS `spec_value`
from ((`needle_db`.`goods_sku_spec` `a` left join `needle_db`.`goods_spec_value` `b` on ((`a`.`spec_value_id` = `b`.`id`)))
         left join `needle_db`.`goods_spec` `c` on ((`b`.`spec_id` = `c`.`id`)))
order by `a`.`sku_id`, `b`.`spec_id`;

