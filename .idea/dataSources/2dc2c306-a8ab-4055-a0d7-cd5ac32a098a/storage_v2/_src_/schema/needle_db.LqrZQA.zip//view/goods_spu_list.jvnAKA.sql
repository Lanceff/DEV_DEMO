create definer = root@`%` view goods_spu_list as
select `spu`.`id`             AS `spu_id`,
       `spu`.`title`          AS `title`,
       `spu`.`img_url`        AS `img_url`,
       `spu`.`brand_id`       AS `brand_id`,
       `spu`.`keyword`        AS `keyword`,
       `brand`.`brand_name`   AS `brand_name`,
       `brand`.`brand_logo`   AS `brand_logo`,
       `spu`.`cate_id`        AS `cate_id`,
       `cate`.`category_name` AS `cate_name`,
       `s`.`low_price`        AS `low_price`,
       `s`.`high_price`       AS `high_price`,
       `s`.`stocks`           AS `stocks`,
       `s`.`sales`            AS `sales`,
       (case
            when ((select count(0)
                   from `needle_db`.`goods_sku`
                   where ((`needle_db`.`goods_sku`.`spu_id` = `spu`.`id`) and (`needle_db`.`goods_sku`.`original_price` is not null))) = 0)
                then '0'
            else '1' end)     AS `is_discount`,
       `spu`.`is_quality`     AS `is_quality`,
       `spu`.`is_hot`         AS `is_hot`,
       `spu`.`is_new`         AS `is_new`
from (((`needle_db`.`goods_spu` `spu` left join `needle_db`.`goods_brand` `brand` on ((`spu`.`brand_id` = `brand`.`id`))) left join `needle_db`.`goods_cate` `cate` on ((`spu`.`cate_id` = `cate`.`id`)))
         left join (select `needle_db`.`goods_sku`.`spu_id`                AS `spu_id`,
                           sum(`needle_db`.`goods_sku`.`sales`)            AS `sales`,
                           sum(`needle_db`.`goods_sku`.`stock`)            AS `stocks`,
                           ifnull(min(`needle_db`.`goods_sku`.`price`), 0) AS `low_price`,
                           ifnull(max(`needle_db`.`goods_sku`.`price`), 0) AS `high_price`
                    from `needle_db`.`goods_sku`
                    where (`needle_db`.`goods_sku`.`status` = '1')
                    group by `needle_db`.`goods_sku`.`spu_id`) `s` on ((`s`.`spu_id` = `spu`.`id`)))
where (`spu`.`status` = '1')
order by `spu`.`id`;

